// JavaScript Document

var fadeShow = $(".background").fadeShow({



	correctRatio: true,



	shuffle: true,



	speed: 2500,



	images: ['images/slider-image-1.jpg',



			 'images/slider-image-2.jpg']







});